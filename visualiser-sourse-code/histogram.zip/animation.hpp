#ifndef _SFML_SORT_ANIM_
#define _SFML_SORT_ANIM_

#include "csv-parser.hpp"
#include <SFML/Graphics.hpp>

void DisplaySortAnimation(FileParser& parser);

void DisplayRow(sf::RenderWindow* window, std::vector<unsigned int> row, std::vector<bool> status_row, unsigned int MaxH);

void DisplayBar(sf::RenderWindow* window, std::vector<unsigned int> row, std::vector<bool> status_row, unsigned int n, unsigned int MaxH);

#endif