#include "animation.hpp"

#include "csv-parser.hpp"
#include <SFML/Graphics.hpp>
#include <iostream>

void DisplaySortAnimation(FileParser& parser) {
    
    std::vector<std::vector<unsigned int>> data = parser.getData();
    unsigned int ArrSize = data[0].size();
    unsigned int RowsTotalNumber = data.size();
    unsigned int MaxElement = data[RowsTotalNumber-1][ArrSize-1];
    unsigned int FrameTime = 20.f / RowsTotalNumber;

    std::vector<bool> TrueRow;
    for (unsigned int j=0; j<ArrSize; j++)
        TrueRow.push_back(true);

    std::vector<std::vector<bool>> status;
    for (unsigned int i=0; i<RowsTotalNumber; i++)
        status.push_back(TrueRow);
    
    for (unsigned int j=0; j<ArrSize; j++)
        for (unsigned int i=RowsTotalNumber-2; i>0; --i)
            if ( !(status[i+1][j]) || data[i][j] != data[i+1][j] )
                status[i][j] = false;
    
    for (unsigned int j=0; j<ArrSize; j++)
        status[RowsTotalNumber-1][j] = false;

    // window setup
    std::cout << "El-s:\tIter-s:" << std::endl;
    std::cout << ArrSize << "\t" << RowsTotalNumber << std::endl;
    std::cout << "Running window" << std::endl;

    sf::RenderWindow window(sf::VideoMode(1600, 900), "Sorting " + parser.getFileName());
    window.setVerticalSyncEnabled(true);
    window.setFramerateLimit(30);

    // clock & animation setup
    sf::Clock clock;
    clock.restart();

    unsigned int iteration = 0;
    bool IsMoving = false;

    while (window.isOpen())
    {
        sf::Event event;
        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
                window.close();

            if (event.type == sf::Event::Resized)
            {
                sf::FloatRect visibleArea(0, 0, event.size.width, event.size.height);
                window.setView(sf::View(visibleArea));
            }
        }

        if ( clock.getElapsedTime().asSeconds() > FrameTime ) {
            clock.restart();
            if ( iteration < RowsTotalNumber-1 )
                iteration += 1;
        }

        // display

        window.clear(sf::Color(80, 100, 120));

        DisplayRow(&window, data[iteration], status[iteration], MaxElement);

        window.display();
    }
    
    std::cout << "Exit (success)" << std::endl;
}

void DisplayRow(sf::RenderWindow* window, std::vector<unsigned int> row, std::vector<bool> status_row, unsigned int MaxH) {    
    for (unsigned int i=0; i<row.size(); i++)
        DisplayBar(window, row, status_row, i, MaxH);
}

void DisplayBar(sf::RenderWindow* window, std::vector<unsigned int> row, std::vector<bool> status_row, unsigned int n, unsigned int MaxH) {
    if ( n >= row.size() )
        return;
    
    unsigned int innmargin = 100;
    unsigned int w = window->getSize().x - 2*innmargin;
    unsigned int h = window->getSize().y - 2*innmargin;

    sf::RectangleShape rectangle(sf::Vector2f(w/row.size() - 3, row[n]*h/MaxH));
    if (status_row[n])
        rectangle.setFillColor(sf::Color::Green);
    else
        rectangle.setFillColor(sf::Color::White);
    rectangle.setPosition( ( innmargin + w/row.size()*n ) , ( innmargin + h - row[n]*h/MaxH ) );
    rectangle.setOutlineColor(sf::Color::Black);
    rectangle.setOutlineThickness(3.f);
    window->draw(rectangle);
}