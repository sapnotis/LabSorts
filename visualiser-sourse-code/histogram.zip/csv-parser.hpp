#ifndef _CSV_PARSER_
#define _CSV_PARSER_

#include <string>
#include <vector>
using std::string;

class FileParser {
private:
    string data_file;
    std::vector<std::vector<unsigned int>> data;
public:
    FileParser(int argc, char *argv[]);
    ~FileParser();
    string getFileName();
    std::vector<std::vector<unsigned int>> getData();
};

#endif