#include "csv-parser.hpp"

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <filesystem>
using std::filesystem::directory_iterator;

unsigned int str2uns(std::string str) {
    unsigned int uns = 0;
    while ( !str.empty() ) {
        if ( 48 <= (unsigned int)str[0] && (unsigned int)str[0] <= 57 ) {
            uns *= 10;
            uns += (unsigned int)(str[0] - '0');
        }
        str.erase(0, 1);
    }
    return uns;
}

FileParser::FileParser(int argc, char *argv[])
{
    if (argc <= 1) {
        for (const auto & entry : directory_iterator("sorts"))
            std::cout << entry.path() << std::endl;
        exit(0);
    }

    if (argc >= 3) {
        std::cout << "Too many arguments" << std::endl;
        exit(0);
    }

    data_file = argv[1];

    std::ifstream file("sorts/" + data_file);
    if (!file.is_open()) {
        std::cout << "Visualiser couldn't find \"" + data_file + "\" in sorts/. Run with no arguments to see the contents" << std::endl;
        exit(0);
    }
    
    std::string line;

    while (std::getline(file, line)) {
        std::stringstream ss(line);
        std::string cell;
        std::vector<unsigned int> row;
        unsigned int number;

        while (std::getline(ss, cell, ',')) {
            number = str2uns(cell);
            row.push_back(number);
        }
        data.push_back(row);
    }

    file.close();
}

FileParser::~FileParser() { }

string FileParser::getFileName()
{
    return this->data_file;
}

std::vector<std::vector<unsigned int>> FileParser::getData()
{
    return this->data;
}